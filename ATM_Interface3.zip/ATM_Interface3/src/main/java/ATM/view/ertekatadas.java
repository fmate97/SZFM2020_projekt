package ATM.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ertekatadas extends ATMLoginController{
    public static final String mentesihely = "file:///C:/Users/Koppany/Documents/NetBeansProjects/ATM_Interface3/";
    
   
    public static final int bankszamladb = 3;
    public static final ObservableList<String> teszt = FXCollections.observableArrayList("123456", "654321", "156678");
}